from app import app
import instagram_api
import instagram_web

if __name__ == '__main__':
    app.run()
